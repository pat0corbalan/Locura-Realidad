import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { tourId, fullName, email, phone, participants, bookingDate } = body

    // Get tour details to calculate total amount
    const { data: tour, error: tourError } = await supabase.from("tours").select("price").eq("id", tourId).single()

    if (tourError || !tour) {
      return NextResponse.json({ error: "Tour not found" }, { status: 404 })
    }

    const totalAmount = tour.price * participants

    // Get current user (optional - bookings can be made without auth)
    const {
      data: { user },
    } = await supabase.auth.getUser()

    // Insert booking
    const { data: booking, error } = await supabase
      .from("bookings")
      .insert({
        user_id: user?.id || null,
        tour_id: tourId,
        full_name: fullName,
        email,
        phone,
        participants,
        total_amount: totalAmount,
        booking_date: bookingDate,
        status: "pending",
      })
      .select()
      .single()

    if (error) {
      console.error("Booking error:", error)
      return NextResponse.json({ error: "Failed to create booking" }, { status: 500 })
    }

    return NextResponse.json({ booking, message: "Booking created successfully" })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: bookings, error } = await supabase
      .from("bookings")
      .select(`
        *,
        tours (
          title,
          location,
          image_url
        )
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: "Failed to fetch bookings" }, { status: 500 })
    }

    return NextResponse.json({ bookings })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
