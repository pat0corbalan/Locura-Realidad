import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { items, customerInfo, shippingAddress } = body

    // Calculate total amount
    let totalAmount = 0
    const productIds = items.map((item: any) => item.productId)

    // Get product prices
    const { data: products, error: productsError } = await supabase
      .from("products")
      .select("id, price, sale_price, is_on_sale")
      .in("id", productIds)

    if (productsError || !products) {
      return NextResponse.json({ error: "Products not found" }, { status: 404 })
    }

    // Calculate total and prepare order items
    const orderItems = items.map((item: any) => {
      const product = products.find((p) => p.id === item.productId)
      if (!product) throw new Error("Product not found")

      const unitPrice = product.is_on_sale && product.sale_price ? product.sale_price : product.price
      const itemTotal = unitPrice * item.quantity
      totalAmount += itemTotal

      return {
        product_id: item.productId,
        quantity: item.quantity,
        unit_price: unitPrice,
        total_price: itemTotal,
      }
    })

    // Get current user (optional - orders can be made without auth)
    const {
      data: { user },
    } = await supabase.auth.getUser()

    // Insert order
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: user?.id || null,
        customer_email: customerInfo.email,
        customer_name: customerInfo.name,
        customer_phone: customerInfo.phone,
        total_amount: totalAmount,
        shipping_address: shippingAddress,
        status: "pending",
      })
      .select()
      .single()

    if (orderError) {
      console.error("Order error:", orderError)
      return NextResponse.json({ error: "Failed to create order" }, { status: 500 })
    }

    // Insert order items
    const orderItemsWithOrderId = orderItems.map((item) => ({
      ...item,
      order_id: order.id,
    }))

    const { error: itemsError } = await supabase.from("order_items").insert(orderItemsWithOrderId)

    if (itemsError) {
      console.error("Order items error:", itemsError)
      return NextResponse.json({ error: "Failed to create order items" }, { status: 500 })
    }

    return NextResponse.json({
      order,
      message: "Order created successfully",
      orderId: order.id,
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: orders, error } = await supabase
      .from("orders")
      .select(`
        *,
        order_items (
          *,
          products (
            name,
            image_url
          )
        )
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
    }

    return NextResponse.json({ orders })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
