import { connectDB } from "@/lib/mongodb";
import { v2 as cloudinary } from "cloudinary";
import Photo from "@/models/Photo";

import { requireAdmin } from "@/lib/admin-auth";
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export async function POST(req) {
  const authError = requireAdmin(req);
  if (authError) return authError;

  await connectDB();

  const contentType = req.headers.get("content-type") || "";
  if (!contentType.includes("multipart/form-data")) {
    return new Response(
      JSON.stringify({ error: "Content-Type must be multipart/form-data" }),
      { status: 400 }
    );
  }

  const form = await req.formData();
  const file = form.get("src");
  const title = form.get("title");
  const alt = form.get("alt");
  const location = form.get("location");

  if (!file || !file.name) {
    return new Response(JSON.stringify({ error: "No se subió una imagen válida" }), { status: 400 });
  }

  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);

  try {
    const result = await new Promise((resolve, reject) => {
      cloudinary.uploader.upload_stream(
        { folder: `photos/${title}` },
        (err, result) => {
          if (err) reject(err);
          else resolve(result);
        }
      ).end(buffer);
    });

    const nuevaFoto = await Photo.create({
      src: result.secure_url,
      alt,
      title,
      location,
    });

    return new Response(JSON.stringify(nuevaFoto), { status: 201 });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Error al subir imagen", detalle: err.message }), {
      status: 500,
    });
  }
}

export async function GET() {
  await connectDB();

  try {
    const photos = await Photo.find();
    return new Response(JSON.stringify(photos), { status: 200 });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 });
  }
}
